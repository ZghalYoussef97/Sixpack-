/********************************************************************************
** Form generated from reading UI file 'accueilequipements.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACCUEILEQUIPEMENTS_H
#define UI_ACCUEILEQUIPEMENTS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AccueilEquipements
{
public:
    QLabel *label_4;
    QLabel *label;
    QPushButton *Modifier_supp;
    QPushButton *Ajouter_nou;
    QLabel *label_3;
    QPushButton *Modifier_supp_2;
    QLabel *label_5;
    QLabel *label_6;
    QPushButton *pushButton;

    void setupUi(QWidget *AccueilEquipements)
    {
        if (AccueilEquipements->objectName().isEmpty())
            AccueilEquipements->setObjectName(QStringLiteral("AccueilEquipements"));
        AccueilEquipements->resize(661, 397);
        AccueilEquipements->setAutoFillBackground(false);
        AccueilEquipements->setStyleSheet(QStringLiteral("background-color:rgb(255, 255, 255)"));
        label_4 = new QLabel(AccueilEquipements);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(260, 280, 161, 16));
        QFont font;
        font.setPointSize(9);
        font.setBold(true);
        font.setWeight(75);
        label_4->setFont(font);
        label = new QLabel(AccueilEquipements);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(-10, 0, 741, 511));
        label->setPixmap(QPixmap(QString::fromUtf8(":/bg.png")));
        Modifier_supp = new QPushButton(AccueilEquipements);
        Modifier_supp->setObjectName(QStringLiteral("Modifier_supp"));
        Modifier_supp->setGeometry(QRect(260, 130, 151, 141));
        Modifier_supp->setStyleSheet(QStringLiteral(""));
        QIcon icon;
        icon.addFile(QStringLiteral(":/logo/edit.png"), QSize(), QIcon::Normal, QIcon::Off);
        Modifier_supp->setIcon(icon);
        Modifier_supp->setIconSize(QSize(150, 150));
        Ajouter_nou = new QPushButton(AccueilEquipements);
        Ajouter_nou->setObjectName(QStringLiteral("Ajouter_nou"));
        Ajouter_nou->setGeometry(QRect(30, 130, 151, 141));
        Ajouter_nou->setStyleSheet(QStringLiteral(""));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/logo/add.png"), QSize(), QIcon::Normal, QIcon::Off);
        Ajouter_nou->setIcon(icon1);
        Ajouter_nou->setIconSize(QSize(150, 150));
        label_3 = new QLabel(AccueilEquipements);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(10, 280, 211, 16));
        label_3->setFont(font);
        Modifier_supp_2 = new QPushButton(AccueilEquipements);
        Modifier_supp_2->setObjectName(QStringLiteral("Modifier_supp_2"));
        Modifier_supp_2->setGeometry(QRect(480, 130, 151, 141));
        Modifier_supp_2->setStyleSheet(QStringLiteral(""));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/logo/stat.png"), QSize(), QIcon::Normal, QIcon::Off);
        Modifier_supp_2->setIcon(icon2);
        Modifier_supp_2->setIconSize(QSize(150, 150));
        Modifier_supp_2->setCheckable(false);
        label_5 = new QLabel(AccueilEquipements);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(520, 280, 161, 16));
        label_5->setFont(font);
        label_6 = new QLabel(AccueilEquipements);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(140, 0, 341, 111));
        label_6->setPixmap(QPixmap(QString::fromUtf8(":/logo/poste.png")));
        pushButton = new QPushButton(AccueilEquipements);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(220, 330, 211, 51));
        pushButton->setLayoutDirection(Qt::LeftToRight);
        pushButton->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/logo/back.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon3);
        pushButton->setIconSize(QSize(40, 40));
        label->raise();
        label_4->raise();
        label_3->raise();
        label_5->raise();
        label_6->raise();
        Modifier_supp->raise();
        Modifier_supp_2->raise();
        Ajouter_nou->raise();
        pushButton->raise();

        retranslateUi(AccueilEquipements);

        QMetaObject::connectSlotsByName(AccueilEquipements);
    } // setupUi

    void retranslateUi(QWidget *AccueilEquipements)
    {
        AccueilEquipements->setWindowTitle(QApplication::translate("AccueilEquipements", "Form", nullptr));
        label_4->setText(QApplication::translate("AccueilEquipements", "Affichage et modification", nullptr));
        label->setText(QString());
        Modifier_supp->setText(QString());
        Ajouter_nou->setText(QString());
        label_3->setText(QApplication::translate("AccueilEquipements", "ajouter un nouveau equipement", nullptr));
        Modifier_supp_2->setText(QString());
        label_5->setText(QApplication::translate("AccueilEquipements", "Statistiques", nullptr));
        label_6->setText(QString());
        pushButton->setText(QApplication::translate("AccueilEquipements", "Retour au menu principal", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AccueilEquipements: public Ui_AccueilEquipements {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACCUEILEQUIPEMENTS_H
