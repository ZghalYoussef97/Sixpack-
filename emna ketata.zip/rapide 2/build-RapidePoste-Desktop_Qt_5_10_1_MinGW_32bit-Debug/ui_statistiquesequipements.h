/********************************************************************************
** Form generated from reading UI file 'statistiquesequipements.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATISTIQUESEQUIPEMENTS_H
#define UI_STATISTIQUESEQUIPEMENTS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_StatistiquesEquipements
{
public:
    QCustomPlot *customPlot;
    QPushButton *pushButton;

    void setupUi(QWidget *StatistiquesEquipements)
    {
        if (StatistiquesEquipements->objectName().isEmpty())
            StatistiquesEquipements->setObjectName(QStringLiteral("StatistiquesEquipements"));
        StatistiquesEquipements->resize(742, 589);
        customPlot = new QCustomPlot(StatistiquesEquipements);
        customPlot->setObjectName(QStringLiteral("customPlot"));
        customPlot->setGeometry(QRect(30, 10, 671, 501));
        pushButton = new QPushButton(StatistiquesEquipements);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(270, 520, 171, 51));
        pushButton->setLayoutDirection(Qt::LeftToRight);
        pushButton->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/logo/back.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon);
        pushButton->setIconSize(QSize(40, 40));

        retranslateUi(StatistiquesEquipements);

        QMetaObject::connectSlotsByName(StatistiquesEquipements);
    } // setupUi

    void retranslateUi(QWidget *StatistiquesEquipements)
    {
        StatistiquesEquipements->setWindowTitle(QApplication::translate("StatistiquesEquipements", "Form", nullptr));
        pushButton->setText(QApplication::translate("StatistiquesEquipements", "Retour au menu", nullptr));
    } // retranslateUi

};

namespace Ui {
    class StatistiquesEquipements: public Ui_StatistiquesEquipements {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATISTIQUESEQUIPEMENTS_H
