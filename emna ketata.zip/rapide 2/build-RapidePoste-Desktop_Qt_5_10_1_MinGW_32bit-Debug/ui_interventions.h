/********************************************************************************
** Form generated from reading UI file 'interventions.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INTERVENTIONS_H
#define UI_INTERVENTIONS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_interventions
{
public:
    QLabel *label_8;
    QTableView *tableView;
    QLabel *label_7;

    void setupUi(QWidget *interventions)
    {
        if (interventions->objectName().isEmpty())
            interventions->setObjectName(QStringLiteral("interventions"));
        interventions->resize(624, 449);
        label_8 = new QLabel(interventions);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(20, 90, 411, 16));
        QFont font;
        font.setPointSize(10);
        label_8->setFont(font);
        tableView = new QTableView(interventions);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(80, 130, 471, 251));
        label_7 = new QLabel(interventions);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(80, 30, 471, 31));
        QFont font1;
        font1.setFamily(QStringLiteral("Stencil"));
        font1.setPointSize(20);
        label_7->setFont(font1);

        retranslateUi(interventions);

        QMetaObject::connectSlotsByName(interventions);
    } // setupUi

    void retranslateUi(QWidget *interventions)
    {
        interventions->setWindowTitle(QApplication::translate("interventions", "Form", nullptr));
        label_8->setText(QApplication::translate("interventions", "Acceuil  >  G\303\251rer Equipements  >  historiques des interventions", nullptr));
        label_7->setText(QApplication::translate("interventions", "Historiques des interventions", nullptr));
    } // retranslateUi

};

namespace Ui {
    class interventions: public Ui_interventions {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INTERVENTIONS_H
