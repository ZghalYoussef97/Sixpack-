/********************************************************************************
** Form generated from reading UI file 'gestionequipements.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GESTIONEQUIPEMENTS_H
#define UI_GESTIONEQUIPEMENTS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GestionEquipements
{
public:
    QWidget *centralWidget;
    QLabel *text4;
    QLabel *label;
    QLabel *label_10;
    QLabel *label_4;
    QLabel *label_6;
    QLabel *label_8;
    QLineEdit *E_reference;
    QTextEdit *E_description;
    QLabel *label_7;
    QLabel *label_11;
    QDateEdit *E_date;
    QLabel *label_9;
    QLabel *text2;
    QLabel *label_2;
    QLineEdit *E_nom;
    QLineEdit *E_service;
    QLineEdit *E_mail;
    QLabel *text5;
    QLabel *text;
    QLabel *text1;
    QLabel *date_text;
    QPushButton *Valider;
    QPushButton *Annuler;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *GestionEquipements)
    {
        if (GestionEquipements->objectName().isEmpty())
            GestionEquipements->setObjectName(QStringLiteral("GestionEquipements"));
        GestionEquipements->resize(643, 557);
        centralWidget = new QWidget(GestionEquipements);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        text4 = new QLabel(centralWidget);
        text4->setObjectName(QStringLiteral("text4"));
        text4->setGeometry(QRect(199, 290, 351, 20));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(-20, -90, 808, 600));
        label->setPixmap(QPixmap(QString::fromUtf8(":/bg1.png")));
        label_10 = new QLabel(centralWidget);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(66, 190, 91, 16));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(66, 270, 131, 16));
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(66, 310, 71, 16));
        label_8 = new QLabel(centralWidget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(109, 70, 261, 16));
        QFont font;
        font.setPointSize(10);
        label_8->setFont(font);
        E_reference = new QLineEdit(centralWidget);
        E_reference->setObjectName(QStringLiteral("E_reference"));
        E_reference->setGeometry(QRect(200, 110, 291, 20));
        E_reference->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        E_description = new QTextEdit(centralWidget);
        E_description->setObjectName(QStringLiteral("E_description"));
        E_description->setGeometry(QRect(199, 310, 291, 121));
        E_description->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(120, -10, 491, 81));
        QFont font1;
        font1.setFamily(QStringLiteral("Stencil"));
        font1.setPointSize(20);
        label_7->setFont(font1);
        label_7->setTextFormat(Qt::RichText);
        label_11 = new QLabel(centralWidget);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(66, 230, 121, 16));
        E_date = new QDateEdit(centralWidget);
        E_date->setObjectName(QStringLiteral("E_date"));
        E_date->setGeometry(QRect(200, 270, 101, 20));
        label_9 = new QLabel(centralWidget);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(66, 110, 131, 16));
        text2 = new QLabel(centralWidget);
        text2->setObjectName(QStringLiteral("text2"));
        text2->setGeometry(QRect(199, 250, 351, 20));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(66, 150, 51, 16));
        E_nom = new QLineEdit(centralWidget);
        E_nom->setObjectName(QStringLiteral("E_nom"));
        E_nom->setGeometry(QRect(200, 150, 291, 20));
        E_nom->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        E_service = new QLineEdit(centralWidget);
        E_service->setObjectName(QStringLiteral("E_service"));
        E_service->setGeometry(QRect(200, 190, 291, 20));
        E_service->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        E_mail = new QLineEdit(centralWidget);
        E_mail->setObjectName(QStringLiteral("E_mail"));
        E_mail->setGeometry(QRect(200, 230, 291, 20));
        E_mail->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        text5 = new QLabel(centralWidget);
        text5->setObjectName(QStringLiteral("text5"));
        text5->setGeometry(QRect(200, 130, 351, 20));
        text = new QLabel(centralWidget);
        text->setObjectName(QStringLiteral("text"));
        text->setGeometry(QRect(200, 170, 351, 20));
        text1 = new QLabel(centralWidget);
        text1->setObjectName(QStringLiteral("text1"));
        text1->setGeometry(QRect(200, 210, 351, 20));
        date_text = new QLabel(centralWidget);
        date_text->setObjectName(QStringLiteral("date_text"));
        date_text->setGeometry(QRect(200, 290, 351, 20));
        Valider = new QPushButton(centralWidget);
        Valider->setObjectName(QStringLiteral("Valider"));
        Valider->setGeometry(QRect(200, 460, 111, 23));
        Valider->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/logo/icons8_ok_96px.png"), QSize(), QIcon::Normal, QIcon::Off);
        Valider->setIcon(icon);
        Annuler = new QPushButton(centralWidget);
        Annuler->setObjectName(QStringLiteral("Annuler"));
        Annuler->setGeometry(QRect(330, 460, 111, 23));
        Annuler->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        GestionEquipements->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(GestionEquipements);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 643, 21));
        GestionEquipements->setMenuBar(menuBar);
        mainToolBar = new QToolBar(GestionEquipements);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        GestionEquipements->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(GestionEquipements);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        GestionEquipements->setStatusBar(statusBar);

        retranslateUi(GestionEquipements);

        QMetaObject::connectSlotsByName(GestionEquipements);
    } // setupUi

    void retranslateUi(QMainWindow *GestionEquipements)
    {
        GestionEquipements->setWindowTitle(QApplication::translate("GestionEquipements", "GestionEquipements", nullptr));
        text4->setText(QString());
        label->setText(QString());
        label_10->setText(QApplication::translate("GestionEquipements", "Service", nullptr));
        label_4->setText(QApplication::translate("GestionEquipements", "Date d'ajout", nullptr));
        label_6->setText(QApplication::translate("GestionEquipements", "Description", nullptr));
        label_8->setText(QApplication::translate("GestionEquipements", "Acceuil  >  G\303\251rer Equipements  >  Ajouter", nullptr));
        E_description->setHtml(QApplication::translate("GestionEquipements", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        label_7->setText(QApplication::translate("GestionEquipements", "Ajouter un nouveau equipement", nullptr));
        label_11->setText(QApplication::translate("GestionEquipements", "Adresse mail de service", nullptr));
        label_9->setText(QApplication::translate("GestionEquipements", "R\303\251ference", nullptr));
        text2->setText(QString());
        label_2->setText(QApplication::translate("GestionEquipements", "Nom", nullptr));
        text5->setText(QString());
        text->setText(QString());
        text1->setText(QString());
        date_text->setText(QString());
        Valider->setText(QApplication::translate("GestionEquipements", "Valider", nullptr));
        Annuler->setText(QApplication::translate("GestionEquipements", "Annuler", nullptr));
    } // retranslateUi

};

namespace Ui {
    class GestionEquipements: public Ui_GestionEquipements {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GESTIONEQUIPEMENTS_H
