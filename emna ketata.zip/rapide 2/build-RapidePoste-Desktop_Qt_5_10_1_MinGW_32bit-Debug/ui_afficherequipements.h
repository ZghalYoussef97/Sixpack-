/********************************************************************************
** Form generated from reading UI file 'afficherequipements.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_AFFICHEREQUIPEMENTS_H
#define UI_AFFICHEREQUIPEMENTS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AfficherEquipements
{
public:
    QLineEdit *Crecherche;
    QLabel *label_7;
    QLabel *label_4;
    QPushButton *annuler;
    QLabel *label_8;
    QPushButton *marche;
    QPushButton *panne;
    QLineEdit *E_nom;
    QTextEdit *E_description;
    QLabel *label_6;
    QLabel *label_10;
    QLineEdit *E_reference;
    QLabel *text2;
    QLabel *label_9;
    QLabel *text;
    QLabel *label_11;
    QLabel *text1;
    QLineEdit *E_mail;
    QLabel *label_5;
    QLineEdit *E_service;
    QTableView *tableView;
    QLabel *label_3;
    QComboBox *comboBox_2;
    QPushButton *modifier_2;
    QPushButton *supprimer;
    QPushButton *historique;
    QPushButton *equipements;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QWidget *AfficherEquipements)
    {
        if (AfficherEquipements->objectName().isEmpty())
            AfficherEquipements->setObjectName(QStringLiteral("AfficherEquipements"));
        AfficherEquipements->resize(839, 521);
        AfficherEquipements->setStyleSheet(QStringLiteral(""));
        Crecherche = new QLineEdit(AfficherEquipements);
        Crecherche->setObjectName(QStringLiteral("Crecherche"));
        Crecherche->setGeometry(QRect(200, 150, 131, 21));
        Crecherche->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-background-color: rgb(187, 187, 187);\n"
"	selection-color: rgb(60, 63, 65);"));
        label_7 = new QLabel(AfficherEquipements);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(210, 30, 381, 31));
        QFont font;
        font.setFamily(QStringLiteral("Stencil"));
        font.setPointSize(20);
        label_7->setFont(font);
        label_4 = new QLabel(AfficherEquipements);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(90, 150, 91, 20));
        annuler = new QPushButton(AfficherEquipements);
        annuler->setObjectName(QStringLiteral("annuler"));
        annuler->setGeometry(QRect(730, 440, 75, 31));
        annuler->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        label_8 = new QLabel(AfficherEquipements);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(90, 90, 411, 16));
        QFont font1;
        font1.setPointSize(10);
        label_8->setFont(font1);
        marche = new QPushButton(AfficherEquipements);
        marche->setObjectName(QStringLiteral("marche"));
        marche->setGeometry(QRect(600, 440, 111, 31));
        marche->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        QIcon icon;
        icon.addFile(QStringLiteral(":/logo/marche.png"), QSize(), QIcon::Normal, QIcon::Off);
        marche->setIcon(icon);
        panne = new QPushButton(AfficherEquipements);
        panne->setObjectName(QStringLiteral("panne"));
        panne->setGeometry(QRect(480, 440, 111, 31));
        panne->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/logo/panne.png"), QSize(), QIcon::Normal, QIcon::Off);
        panne->setIcon(icon1);
        E_nom = new QLineEdit(AfficherEquipements);
        E_nom->setObjectName(QStringLiteral("E_nom"));
        E_nom->setGeometry(QRect(130, 230, 181, 20));
        E_nom->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"	selection-background-color: rgb(187, 187, 187);\n"
"	selection-color: rgb(60, 63, 65);"));
        E_description = new QTextEdit(AfficherEquipements);
        E_description->setObjectName(QStringLiteral("E_description"));
        E_description->setGeometry(QRect(120, 360, 201, 101));
        E_description->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"\n"
"	border-style: inset;\n"
"\n"
"\n"
""));
        label_6 = new QLabel(AfficherEquipements);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(10, 390, 71, 16));
        label_10 = new QLabel(AfficherEquipements);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(10, 270, 91, 16));
        E_reference = new QLineEdit(AfficherEquipements);
        E_reference->setObjectName(QStringLiteral("E_reference"));
        E_reference->setGeometry(QRect(130, 190, 181, 20));
        E_reference->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"	selection-background-color: rgb(187, 187, 187);\n"
"	selection-color: rgb(60, 63, 65);"));
        text2 = new QLabel(AfficherEquipements);
        text2->setObjectName(QStringLiteral("text2"));
        text2->setGeometry(QRect(140, 330, 191, 20));
        label_9 = new QLabel(AfficherEquipements);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(10, 190, 111, 16));
        text = new QLabel(AfficherEquipements);
        text->setObjectName(QStringLiteral("text"));
        text->setGeometry(QRect(130, 250, 201, 20));
        label_11 = new QLabel(AfficherEquipements);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(10, 310, 121, 16));
        text1 = new QLabel(AfficherEquipements);
        text1->setObjectName(QStringLiteral("text1"));
        text1->setGeometry(QRect(130, 290, 201, 20));
        E_mail = new QLineEdit(AfficherEquipements);
        E_mail->setObjectName(QStringLiteral("E_mail"));
        E_mail->setGeometry(QRect(130, 310, 181, 20));
        E_mail->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-background-color: rgb(187, 187, 187);\n"
"	selection-color: rgb(60, 63, 65);"));
        label_5 = new QLabel(AfficherEquipements);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(10, 230, 51, 16));
        E_service = new QLineEdit(AfficherEquipements);
        E_service->setObjectName(QStringLiteral("E_service"));
        E_service->setGeometry(QRect(130, 270, 181, 20));
        E_service->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-background-color: rgb(187, 187, 187);\n"
"	selection-color: rgb(60, 63, 65);"));
        tableView = new QTableView(AfficherEquipements);
        tableView->setObjectName(QStringLiteral("tableView"));
        tableView->setGeometry(QRect(340, 180, 491, 251));
        tableView->setStyleSheet(QStringLiteral(""));
        label_3 = new QLabel(AfficherEquipements);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(120, 120, 41, 16));
        comboBox_2 = new QComboBox(AfficherEquipements);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(200, 120, 81, 22));
        comboBox_2->setStyleSheet(QStringLiteral(""));
        modifier_2 = new QPushButton(AfficherEquipements);
        modifier_2->setObjectName(QStringLiteral("modifier_2"));
        modifier_2->setGeometry(QRect(130, 470, 111, 31));
        modifier_2->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/logo/edit.png"), QSize(), QIcon::Normal, QIcon::Off);
        modifier_2->setIcon(icon2);
        supprimer = new QPushButton(AfficherEquipements);
        supprimer->setObjectName(QStringLiteral("supprimer"));
        supprimer->setGeometry(QRect(360, 440, 111, 31));
        supprimer->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        QIcon icon3;
        icon3.addFile(QStringLiteral(":/logo/delete.png"), QSize(), QIcon::Normal, QIcon::Off);
        supprimer->setIcon(icon3);
        historique = new QPushButton(AfficherEquipements);
        historique->setObjectName(QStringLiteral("historique"));
        historique->setGeometry(QRect(520, 120, 201, 31));
        historique->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        QIcon icon4;
        icon4.addFile(QStringLiteral(":/logo/history.png"), QSize(), QIcon::Normal, QIcon::Off);
        historique->setIcon(icon4);
        equipements = new QPushButton(AfficherEquipements);
        equipements->setObjectName(QStringLiteral("equipements"));
        equipements->setGeometry(QRect(520, 120, 201, 31));
        equipements->setStyleSheet(QLatin1String("	border-width: 1px; border-radius: 4px;\n"
"	border-color: rgb(58, 58, 58);\n"
"	border-style: inset;\n"
"	padding: 0 8px;\n"
"\n"
"\n"
"	selection-color: rgb(60, 63, 65);"));
        QIcon icon5;
        icon5.addFile(QStringLiteral(":/logo/back.png"), QSize(), QIcon::Normal, QIcon::Off);
        equipements->setIcon(icon5);
        pushButton = new QPushButton(AfficherEquipements);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(180, 150, 16, 21));
        pushButton->setStyleSheet(QLatin1String("\n"
"	border-width: 0px; border-radius: 0px;\n"
"\n"
"	border-style: inset;\n"
"   border-color:transparent;\n"
"	color: rgb(255, 255, 255);\n"
"\n"
"	selection-background-color:transparent;\n"
"	selection-color:transparent;"));
        QIcon icon6;
        icon6.addFile(QStringLiteral(":/logo/icons8_search_property_96px.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton->setIcon(icon6);
        pushButton_2 = new QPushButton(AfficherEquipements);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(170, 120, 16, 21));
        pushButton_2->setLayoutDirection(Qt::RightToLeft);
        pushButton_2->setStyleSheet(QLatin1String("\n"
"	border-width: 0px; border-radius: 0px;\n"
"\n"
"	border-style: inset;\n"
"   border-color:transparent;\n"
"	color: rgb(255, 255, 255);\n"
"\n"
"	selection-background-color:transparent;\n"
"	selection-color:transparent;"));
        QIcon icon7;
        icon7.addFile(QStringLiteral(":/logo/icons8_alphabetical_sorting_96px.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_2->setIcon(icon7);

        retranslateUi(AfficherEquipements);

        QMetaObject::connectSlotsByName(AfficherEquipements);
    } // setupUi

    void retranslateUi(QWidget *AfficherEquipements)
    {
        AfficherEquipements->setWindowTitle(QApplication::translate("AfficherEquipements", "Form", nullptr));
        Crecherche->setPlaceholderText(QApplication::translate("AfficherEquipements", "rechercher", nullptr));
        label_7->setText(QApplication::translate("AfficherEquipements", "Gestion des \303\251quipements ", nullptr));
        label_4->setText(QApplication::translate("AfficherEquipements", "reference/service", nullptr));
        annuler->setText(QApplication::translate("AfficherEquipements", "Annuler", nullptr));
        label_8->setText(QApplication::translate("AfficherEquipements", "Acceuil  >  G\303\251rer Equipements    >  affichage et modification", nullptr));
        marche->setText(QApplication::translate("AfficherEquipements", "En marche", nullptr));
        panne->setText(QApplication::translate("AfficherEquipements", "En panne", nullptr));
        E_description->setHtml(QApplication::translate("AfficherEquipements", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><br /></p></body></html>", nullptr));
        label_6->setText(QApplication::translate("AfficherEquipements", "Description", nullptr));
        label_10->setText(QApplication::translate("AfficherEquipements", "Service", nullptr));
        text2->setText(QString());
        label_9->setText(QApplication::translate("AfficherEquipements", "R\303\251ference", nullptr));
        text->setText(QString());
        label_11->setText(QApplication::translate("AfficherEquipements", "Adresse mail de service", nullptr));
        text1->setText(QString());
        label_5->setText(QApplication::translate("AfficherEquipements", "Nom", nullptr));
        label_3->setText(QApplication::translate("AfficherEquipements", "TRI PAR :", nullptr));
        comboBox_2->setItemText(0, QApplication::translate("AfficherEquipements", "NOM", nullptr));
        comboBox_2->setItemText(1, QApplication::translate("AfficherEquipements", "Reference", nullptr));

        modifier_2->setText(QApplication::translate("AfficherEquipements", "modifier", nullptr));
        supprimer->setText(QApplication::translate("AfficherEquipements", "supprimer", nullptr));
        historique->setText(QApplication::translate("AfficherEquipements", "Historique des interventions", nullptr));
        equipements->setText(QApplication::translate("AfficherEquipements", "Retour au equipements", nullptr));
        pushButton->setText(QString());
        pushButton_2->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class AfficherEquipements: public Ui_AfficherEquipements {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_AFFICHEREQUIPEMENTS_H
