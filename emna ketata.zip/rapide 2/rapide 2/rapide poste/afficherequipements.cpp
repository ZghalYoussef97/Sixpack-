#include "afficherequipements.h"
#include "ui_afficherequipements.h"
#include "equipements.h"
#include "afficherequipements.h"
#include "accueilequipements.h"
#include "interventions.h"
#include "connexion.h"
#include <QMessageBox>
int ind=0;
int ind2=0;
AfficherEquipements::AfficherEquipements(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AfficherEquipements)

{
    ui->setupUi(this);
    equipements e;
    ui->equipements->hide();
    e.afficher(ui);
    setWindowFlags(Qt::WindowMinimizeButtonHint);//autorise le bouton de réduction de fenêtre
    setWindowFlags(Qt::WindowFullscreenButtonHint);
    setWindowFlags(Qt::WindowCloseButtonHint);//autorise le bouton de fermeture dans le bandeau de fenêtre


    ui->Crecherche->setStyleSheet(("QlineEdit {color:black;}"));

}

AfficherEquipements::~AfficherEquipements()
{
    delete ui;
}



void AfficherEquipements::on_tableView_activated(const QModelIndex &index)
{

}

void AfficherEquipements::on_panne_clicked()
{
    equipements e;
    e.en_panne(ui);
    e.afficher(ui);
}
void AfficherEquipements::on_marche_clicked()
{
    equipements e;
    e.en_marche(ui);
    e.afficher(ui);
}
void AfficherEquipements::on_recherche_clicked()
{

}


void AfficherEquipements::on_comboBox_currentIndexChanged(int index)
{
    equipements e;
    if (index==0)
    { ind=0 ;
    }
    else
    { ind=1;

    }
}



void AfficherEquipements::on_comboBox_2_currentIndexChanged(const QString &arg1)
{

}

void AfficherEquipements::on_comboBox_2_currentIndexChanged(int index)
{
    equipements e;
    if (index==0)
    {  e.Tri_NOM(ui);}

    else
    {  e.Tri_Ref(ui);

    }
}



void AfficherEquipements::on_modifier_2_clicked()
{
    // verification nom
    QRegExp REG1 ("[a-z]$");
    QRegExp REG2 ("^[a-z]");
    QRegExp REG3 ("^[\\w|\\.]+@[\\w]+\\.[\\w]{2,4}$");

    QString msg_nom ="le nom est invalide";
    QString msg_service ="le nom de service est invalide";
    QString msg_ref ="la reference doit etre composé de 8 chiffres ";
    QString msg_adresse="la format de l'adresse est invalide";
    QString msg_vide="";


    QString nom= ui->E_nom->text();
    QString reference= ui->E_reference->text();
    QString service= ui->E_service->text();
    QString email= ui->E_mail->text();
    QString description= ui->E_description->toPlainText();


    equipements e;



    if ((!nom.contains(REG1))||(!nom.contains(REG2)))
    {

        ui->E_nom->setStyleSheet("QLineEdit { color: red;}");
        ui->text->setText(msg_nom);
        ui->text->setStyleSheet("QLabel { background-color : transparent; color : red; }");
        e.set_erreur();
    }
    else { ui->E_nom->setStyleSheet("QLineEdit { color: black;}");
        ui->text->setText(msg_vide);

    }

    if ((!service.contains(REG1))||(!service.contains(REG2)))
    {

        ui->E_service->setStyleSheet("QLineEdit { color: red;}");
        e.set_erreur();
        ui->text1->setText(msg_service);
        ui->text1->setStyleSheet("QLabel { background-color : transparent; color : red; }");
    }
    else { ui->E_service->setStyleSheet("QLineEdit { color: black;}");
        ui->text1->setText(msg_vide);
    }


    if (!email.contains(REG3))
    {

        ui->E_mail->setStyleSheet("QLineEdit { color: red;}");
        ui->text2->setText(msg_adresse);
        ui->text2->setStyleSheet("QLabel { background-color : transparent; color : red; }");
        e.set_erreur();
    }
    else { ui->E_mail->setStyleSheet("QLineEdit { color: black;}");
        ui->text2->setText(msg_vide);
    }
    if (e.get_erreurs()==0)
    {
        if ( e.modifier(ui))
        {
            QMessageBox ::information(this,"","Equipements bien modifié")  ;
            ui->E_nom->setStyleSheet("QLineEdit { color: green;}");
            ui->E_reference->setStyleSheet("QLineEdit { color: green;}");
            ui->E_mail->setStyleSheet("QLineEdit { color: green;}");
            ui->E_service->setStyleSheet("QLineEdit { color: green;}");

            e.afficher(ui);
        }
        else
        {QMessageBox ::critical(this,"","erreur d'ajout \n reference dupliquée") ;
            ui->E_reference->setStyleSheet("QLineEdit { color: red;}");
        }
    }

    else
    {QMessageBox ::information(this,"","erreur de modification  ") ;

    }
}

void AfficherEquipements::on_modifier_clicked()
{

}

void AfficherEquipements::on_Crecherche_textChanged(const QString &arg1)
{
    QString result ;
    equipements e;


    e.Recherche(ui);
}

void AfficherEquipements::on_Crecherche_textEdited(const QString &arg1)
{

}

void AfficherEquipements::on_tableView_clicked(const QModelIndex &index)
{


    QString val;
    val=ui->tableView->model()->data(ui->tableView->model()->index(ui->tableView->selectionModel()->currentIndex().row(),0)).toString();
    QSqlQuery qry;
    qry.prepare("select * from EQUIPEMENTS where reference='"+val+"'");
    if(qry.exec())
    {while(qry.next())
        {
            ui->E_reference->setText(qry.value(0).toString());
            ui->E_reference->setDisabled(true);
            ui->E_nom->setText(qry.value(1).toString());
            ui->E_service->setText(qry.value(2).toString());
            ui->E_mail->setText(qry.value(3).toString());
            ui->E_description->setText(qry.value(5).toString());

        }
    }
    else { QMessageBox ::information(this,"","erreur "  ) ;}
}

void AfficherEquipements::on_annuler_clicked()
{
    AccueilEquipements *w = new AccueilEquipements;
    hide();
    w->show();

}

void AfficherEquipements::on_supprimer_clicked()
{
    equipements e;
    e.Supprimer(ui);
    e.afficher(ui);
}

void AfficherEquipements::on_historique_clicked()
{

    ui->historique->hide();
    ui->comboBox_2->hide();
    ui->Crecherche->hide();
    ui->supprimer->hide();
    ui->marche->hide();
    ui->panne->hide();
    ui->pushButton->hide();
    ui->pushButton_2->hide();
    ui->modifier_2->hide();
    ui->label_4->hide();
    ui->label_3->hide();

    ui->equipements->show();
    equipements e;

    e.afficherIntervention(ui);
}

void AfficherEquipements::on_equipements_clicked()
{
    ui->historique->show();
    ui->historique->show();
    ui->comboBox_2->show();
    ui->Crecherche->show();
    ui->supprimer->show();
    ui->marche->show();
    ui->panne->show();
    ui->pushButton->show();
    ui->pushButton_2->show();
    ui->modifier_2->show();
    ui->label_4->show();
    ui->label_3->show();
    ui->equipements->hide();
    equipements e;

    e.afficher(ui);
}
