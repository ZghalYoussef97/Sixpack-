#ifndef STATISTIQUESEQUIPEMENTS_H
#define STATISTIQUESEQUIPEMENTS_H

#include <QWidget>

namespace Ui {
class StatistiquesEquipements;
}

class StatistiquesEquipements : public QWidget
{
    Q_OBJECT

public:
    explicit StatistiquesEquipements(QWidget *parent = 0);
    ~StatistiquesEquipements();



    int getNbre_marche() ;

    void setNbre_marche(int value);

    int getNbre_panne();

    void setNbre_panne(int value);

    int getNbre_total() ;

    void setNbre_total(int value);

private slots:
    void makePlot();
    void on_pushButton_clicked();

private:
    Ui::StatistiquesEquipements *ui;
    int  nbre_marche;
    int nbre_panne ;
    int nbre_total ;
};

#endif // STATISTIQUESEQUIPEMENTS_H




