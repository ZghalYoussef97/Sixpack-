#include "interventions.h"
#include "ui_interventions.h"
#include "equipements.h"
#include "connexion.h"
#include <QMessageBox>
interventions::interventions(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::interventions)
{

    ui->setupUi(this);
}

interventions::~interventions()
{
    delete ui;
}


