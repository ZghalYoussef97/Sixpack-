#include "accueilequipements.h"
#include "ui_accueilequipements.h"
#include "afficherequipements.h"
#include "gestionequipements.h"
#include "statistiquesequipements.h"
AccueilEquipements::AccueilEquipements(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AccueilEquipements)
{
    ui->setupUi(this);
}

AccueilEquipements::~AccueilEquipements()
{
    delete ui;
}

void AccueilEquipements::on_Ajouter_nou_clicked()
{



    GestionEquipements *w = new GestionEquipements;
    hide();
    w->show();

}

void AccueilEquipements::on_Modifier_supp_clicked()
{
    AfficherEquipements *w = new AfficherEquipements;
    hide();
    w->show();

}

void AccueilEquipements::on_Modifier_supp_2_clicked()
{
    StatistiquesEquipements *w = new StatistiquesEquipements;
    hide();
    w->show();
}
