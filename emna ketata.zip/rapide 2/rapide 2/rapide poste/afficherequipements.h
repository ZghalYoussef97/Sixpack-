#ifndef AFFICHEREQUIPEMENTS_H
#define AFFICHEREQUIPEMENTS_H
#include "equipements.h"

#include <QWidget>

namespace Ui {
class AfficherEquipements;

}

class AfficherEquipements : public QWidget
{
    Q_OBJECT

public:
    explicit AfficherEquipements(QWidget *parent = 0);
    ~AfficherEquipements();

private slots:


    void on_tableView_activated(const QModelIndex &index);

    void on_panne_clicked();

    void on_recherche_clicked();

    void on_comboBox_currentIndexChanged(int index);

    void on_comboBox_2_currentIndexChanged(const QString &arg1);

    void on_comboBox_2_currentIndexChanged(int index);



    void on_marche_clicked();

    void on_modifier_clicked();

    void on_modifier_2_clicked();

    void on_Crecherche_textChanged(const QString &arg1);

    void on_Crecherche_textEdited(const QString &arg1);

    void on_tableView_clicked(const QModelIndex &index);

    void on_annuler_clicked();

    void on_supprimer_clicked();

    void on_historique_clicked();

    void on_equipements_clicked();

private:
    Ui::AfficherEquipements *ui;

};

#endif // AFFICHEREQUIPEMENTS_H
