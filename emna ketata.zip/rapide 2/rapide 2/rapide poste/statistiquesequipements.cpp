#include "statistiquesequipements.h"
#include "ui_statistiquesequipements.h"
#include "equipements.h"
#include "accueilequipements.h"
StatistiquesEquipements::StatistiquesEquipements(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::StatistiquesEquipements)
{
    ui->setupUi(this);
    StatistiquesEquipements::makePlot();
    setWindowTitle(tr("Statistiques"));
}

StatistiquesEquipements::~StatistiquesEquipements()
{
    delete ui;
}

int StatistiquesEquipements::getNbre_marche()
{
    return nbre_marche;
}

void StatistiquesEquipements::setNbre_marche(int value)
{
    nbre_marche = value;
}

int StatistiquesEquipements::getNbre_panne()
{
    return nbre_panne;
}

void StatistiquesEquipements::setNbre_panne(int value)
{
    nbre_panne = value;
}

int StatistiquesEquipements::getNbre_total()
{
    return nbre_total;
}

void StatistiquesEquipements::setNbre_total(int value)
{
    nbre_total = value;
}





void StatistiquesEquipements::makePlot()
{ equipements e;
    nbre_marche=e.nbre_En_Marche();
    nbre_panne=e.nbre_En_Panne();
    nbre_total=e.nbre_total();
    // set dark background gradient:
    QLinearGradient gradient(0, 0, 0, 400);
    gradient.setColorAt(0, QColor(90, 90, 90));
    gradient.setColorAt(0.38, QColor(105, 105, 105));
    gradient.setColorAt(1, QColor(70, 70, 70));
    ui->customPlot->setBackground(QBrush(gradient));

    // create empty bar chart objects:

    QCPBars *Panne = new QCPBars(ui->customPlot->xAxis, ui->customPlot->yAxis);
    QCPBars *Marche = new QCPBars(ui->customPlot->xAxis, ui->customPlot->yAxis);

    Panne->setAntialiased(false);
    Marche->setAntialiased(false);

    Panne->setStackingGap(1);
    Marche->setStackingGap(1);

    // set names and colors:
    Marche->setName("Equipements en Marche");
    Marche->setPen(QPen(QColor(0, 125, 2).lighter(170)));
    Marche->setBrush(QColor(0, 125, 2));
    Panne->setName("Equipements en Panne");
    Panne->setPen(QPen(QColor(174, 0, 0).lighter(150)));
    Panne->setBrush(QColor(174, 0, 0));

    // prepare x axis :
    QVector<double> ticks;
    QVector<QString> labels;
    ticks << 1 << 2 ;

    QSharedPointer<QCPAxisTickerText> textTicker(new QCPAxisTickerText);
    textTicker->addTicks(ticks, labels);
    ui->customPlot->xAxis->setTicker(textTicker);
    ui->customPlot->xAxis->setTickLabelRotation(60);
    ui->customPlot->xAxis->setSubTicks(false);
    ui->customPlot->xAxis->setTickLength(0, 4);
    ui->customPlot->xAxis->setRange(0, 4);
    ui->customPlot->xAxis->setBasePen(QPen(Qt::white));
    ui->customPlot->xAxis->setTickPen(QPen(Qt::white));
    ui->customPlot->xAxis->grid()->setVisible(true);
    ui->customPlot->xAxis->grid()->setPen(QPen(QColor(130, 130, 130), 0, Qt::DotLine));
    ui->customPlot->xAxis->setTickLabelColor(Qt::white);
    ui->customPlot->xAxis->setLabelColor(Qt::white);

    // prepare y axis:
    ui->customPlot->yAxis->setRange(0, nbre_total);
    ui->customPlot->yAxis->setPadding(1);// a bit more space to the left border
    ui->customPlot->yAxis->setLabel("Nombre des equipements total");
    ui->customPlot->yAxis->setBasePen(QPen(Qt::white));
    ui->customPlot->yAxis->setTickPen(QPen(Qt::white));
    ui->customPlot->yAxis->setSubTickPen(QPen(Qt::white));


    ui->customPlot->yAxis->grid()->setSubGridVisible(true);
    ui->customPlot->yAxis->setTickLabelColor(Qt::white);
    ui->customPlot->yAxis->setLabelColor(Qt::white);
    ui->customPlot->yAxis->grid()->setPen(QPen(QColor(130, 130, 130), 0, Qt::SolidLine));
    ui->customPlot->yAxis->grid()->setSubGridPen(QPen(QColor(130, 130, 130), 0, Qt::DotLine));

    // Add data:
    QVector<double> PanneData, MarcheDate;
    PanneData  << nbre_panne <<0 ;
    MarcheDate << 00 << nbre_marche;

    Panne->setData(ticks, PanneData);
    Marche->setData(ticks, MarcheDate);


    // setup legend:
    ui->customPlot->legend->setVisible(true);
    ui->customPlot->axisRect()->insetLayout()->setInsetAlignment(0, Qt::AlignTop|Qt::AlignHCenter);
    ui->customPlot->legend->setBrush(QColor(255, 255, 255, 100));
    ui->customPlot->legend->setBorderPen(Qt::NoPen);
    QFont legendFont = font();
    legendFont.setPointSize(10);
    ui->customPlot->legend->setFont(legendFont);
    ui->customPlot->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom);

}

void StatistiquesEquipements::on_pushButton_clicked()
{
    AccueilEquipements *w = new  AccueilEquipements;
    hide();
    w->show();
}
