#include "gestionequipements.h"
#include "afficherequipements.h"
#include "accueilequipements.h"
#include <QApplication>
#include "connexion.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    AccueilEquipements w;
    Connexion c;
    bool test=c.ouvrirConnexion();
    w.show();

    return a.exec();
}
