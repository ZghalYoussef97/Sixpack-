#ifndef ACCUEILEQUIPEMENTS_H
#define ACCUEILEQUIPEMENTS_H

#include <QWidget>

namespace Ui {
class AccueilEquipements;
}

class AccueilEquipements : public QWidget
{
    Q_OBJECT

public:
    explicit AccueilEquipements(QWidget *parent = 0);
    ~AccueilEquipements();

private slots:
    void on_Ajouter_nou_clicked();

    void on_Modifier_supp_clicked();

    void on_Modifier_supp_2_clicked();

private:
    Ui::AccueilEquipements *ui;
};

#endif // ACCUEILEQUIPEMENTS_H
