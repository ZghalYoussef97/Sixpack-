#ifndef INTERVENTIONS_H
#define INTERVENTIONS_H

#include <QWidget>

namespace Ui {
class interventions;
}

class interventions : public QWidget
{
    Q_OBJECT

public:
    explicit interventions(QWidget *parent = 0);
    ~interventions();


private:
    Ui::interventions *ui;
};

#endif // INTERVENTIONS_H
