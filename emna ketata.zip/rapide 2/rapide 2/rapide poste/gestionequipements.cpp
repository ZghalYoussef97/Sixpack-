#include "gestionequipements.h"
#include "ui_gestionequipements.h"
#include "equipements.h"
#include "accueilequipements.h"
#include <QMessageBox>
GestionEquipements::GestionEquipements(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::GestionEquipements)
{
    ui->setupUi(this);
    QDate y1=QDate::currentDate();

    ui->E_date->setDate(y1);
    ui->E_date->setDisabled(true);
}

GestionEquipements::~GestionEquipements()
{
    delete ui;
}

void GestionEquipements::on_Valider_clicked()
{



    QRegExp REG1 ("[a-z]$");
    QRegExp REG2 ("^[a-z]");
    QRegExp REG3 ("^[\\w|\\.]+@[\\w]+\\.[\\w]{2,4}$");

    QString msg_nom ="le nom est invalide";
    QString msg_service ="le nom de service est invalide";
    QString msg_ref ="la reference doit etre composé de 8 chiffres ";
    QString msg_adresse="la format de l'adresse est invalide";
    QString msg_vide="";
    QString nom= ui->E_nom->text();
    QString reference= ui->E_reference->text();
    QString service= ui->E_service->text();
    QString email= ui->E_mail->text();
    QString description= ui->E_description->toPlainText();
    QDate date= ui->E_date->date();
    equipements e(reference,nom,service,email,date,description);



    if(reference.size()==8)
    {ui->E_reference->setStyleSheet("QLineEdit { color: black;}");
        ui->text5->setText(msg_vide);}
    else {
        ui->E_reference->setStyleSheet("QLineEdit { color: red;}");
        e.set_erreur();
        ui->text5->setText(msg_ref);
        ui->text5->setStyleSheet("QLabel { background-color : transparent; color : red; }");
    }

    if ((!nom.contains(REG1))||(!nom.contains(REG2)))
    {

        ui->E_nom->setStyleSheet("QLineEdit { color: red;}");
        ui->text->setText(msg_nom);
        ui->text->setStyleSheet("QLabel { background-color : transparent; color : red; }");
        e.set_erreur();
    }
    else { ui->E_nom->setStyleSheet("QLineEdit { color: black;}");
        ui->text->setText(msg_vide);

    }

    if ((!service.contains(REG1))||(!service.contains(REG2)))
    {

        ui->E_service->setStyleSheet("QLineEdit { color: red;}");
        e.set_erreur();
        ui->text1->setText(msg_service);
        ui->text1->setStyleSheet("QLabel { background-color : transparent; color : red; }");
    }
    else { ui->E_service->setStyleSheet("QLineEdit { color: black;}");
        ui->text1->setText(msg_vide);
    }


    if (!email.contains(REG3))
    {

        ui->E_mail->setStyleSheet("QLineEdit { color: red;}");
        ui->text2->setText(msg_adresse);
        ui->text2->setStyleSheet("QLabel { background-color : transparent; color : red; }");
        e.set_erreur();
    }
    else { ui->E_mail->setStyleSheet("QLineEdit { color: black;}");
        ui->text2->setText(msg_vide);
    }

    QDate y=ui->E_date->date();
    QDate y1=QDate::currentDate();
    if ((y.year()<(y1.year()))||( y.month()>y1.month() )||( y.day()>y1.day() ))
    {  e.set_erreur();
        ui->date_text->setText("date invalide");
        ui->date_text->setStyleSheet("QLabel { background-color : transparent; color : red; }");
    }
    else
    { ui->date_text->setText(msg_vide);}


    if (e.get_erreurs()==0)
    {
        if (e.ajouter())
        {
            QMessageBox ::information(this,"","Equipement bien ajoute")  ;
            ui->E_nom->setStyleSheet("QLineEdit { color: green;}");
            ui->E_reference->setStyleSheet("QLineEdit { color: green;}");
            ui->E_mail->setStyleSheet("QLineEdit { color: green;}");
            ui->E_service->setStyleSheet("QLineEdit { color: green;}");
            ui->E_date->setStyleSheet("QLineEdit { color: green;}");

        }
        else
        {QMessageBox ::critical(this,"","erreur d'ajout \n reference dupliquée") ;
            ui->E_reference->setStyleSheet("QLineEdit { color: red;}");
        }
    }

    else
    {QMessageBox ::information(this,"","erreur d'ajout  ") ;

    }
}

void GestionEquipements::on_Annuler_clicked()
{
    AccueilEquipements *w = new AccueilEquipements;
    hide();
    w->show();

}
