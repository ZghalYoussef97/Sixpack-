#include "equipements.h"
#include "afficherequipements.h"
#include "gestionequipements.h"
#include "interventions.h"
#include "ui_interventions.h"
equipements::equipements()
{

}

equipements::equipements(QString reference, QString nom, QString service, QString mail,QDate date_ajout, QString descreption)
{
    this->reference=reference;
    this->nom=nom;
    this->service=service;
    this->mail=mail;
    this->etat=etat;
    this->descreption=descreption;
    this->date_ajout=date_ajout;
}

QString equipements :: get_nom(){return  nom;}
QString equipements::get_reference(){return reference;}
QString equipements:: get_service() {return service ;}
QString equipements::get_mail()  {return mail;}
QString equipements::get_desc() {return descreption;}
QDate equipements :: get_Date() {return date_ajout  ;}
int equipements::get_erreurs() {return erreurs ;}
void equipements::set_erreur() { erreurs ++ ; }



/**********************************************************************************/
bool equipements::ajouter()
{
    QSqlQuery query;

    query.prepare("INSERT INTO EQUIPEMENTS (REFERENCE, NOM, SERVICE,EMAIL,DATE_AJOUT,DESCRIPTION,ETAT) "
                  "VALUES (:reference, :nom, :service,:email,:date,:description,:etat)");
    query.bindValue(":reference",reference);
    query.bindValue(":nom", nom);
    query.bindValue(":service",service );
    query.bindValue(":email", mail);
    query.bindValue(":date", date_ajout);
    query.bindValue(":description", descreption);
    query.bindValue(":etat", "en marche");
    return    query.exec();
}

/***************************************************************************************/
bool equipements::Supprimer(Ui::AfficherEquipements *ui)
{
    QSqlQuery q;
    bool e;
    q.prepare("DELETE FROM equipements WHERE reference ='"+ui->tableView->model()->data(ui->tableView->model()->index(ui->tableView->selectionModel()->currentIndex().row(),0)).toString()+"'");
    q.exec();
    if(q.first())
    {
        e=true;
    }
    else
    {
        e=false;
    }

}
/*******************************************************************************************/



bool equipements::modifier(Ui::AfficherEquipements *ui )
{
    QSqlQuery q;

    QString val=ui->tableView->model()->data(ui->tableView->model()->index(ui->tableView->selectionModel()->currentIndex().row(),0)).toString();

    q.prepare("UPDATE equipements set NOM=:nom,service=:service,EMAIL=:mail,DESCRIPTION=:description where reference='"+val+"'") ;


    q.bindValue(":nom",ui->E_nom->text());
    q.bindValue(":service",ui->E_service->text());
    q.bindValue(":mail",ui->E_mail->text());
    q.bindValue(":description",ui->E_description->toPlainText());

    if ( q.exec())
    {
        return true ;
    }
    else
    {
        return false;
    }
}

/*****************************************************************************/

void equipements::afficher(Ui::AfficherEquipements *ui)
{
    QSqlQuery q;
    QSqlQueryModel *modal=new QSqlQueryModel();
    q.prepare("select * from equipements");
    q.exec();
    modal->setQuery(q);
    ui->tableView->setModel(modal);


}

void equipements::afficherIntervention(Ui::AfficherEquipements *ui)
{
    QSqlQuery q;
    QSqlQueryModel *modal=new QSqlQueryModel();
    q.prepare("select * from interventions");
    q.exec();
    modal->setQuery(q);
    ui->tableView->setModel(modal);


}

/****************************************************************************/
void equipements::Tri_Ref(Ui::AfficherEquipements *ui)
{
    QSqlQuery q;
    QSqlQueryModel *model=new QSqlQueryModel();
    q.prepare("select * from equipements order by reference");
    q.exec();
    model->setQuery(q);
    ui->tableView->setModel(model);
}
/**************************************************************************/
void equipements::Tri_NOM(Ui::AfficherEquipements *ui)
{
    QSqlQuery q;
    QSqlQueryModel *model=new QSqlQueryModel();
    q.prepare("select * from equipements order by NOM");
    q.exec();
    model->setQuery(q);
    ui->tableView->setModel(model);
}

/****************************************************************************/
void equipements::Recherche(Ui::AfficherEquipements *ui)
{  QString num;
    QSqlQuery q;
    QSqlQueryModel *modal=new QSqlQueryModel();
    QString reference =ui->Crecherche->text();
    q.prepare("select * from equipements where (reference LIKE '%"+reference+"%' or NOM LIKE '%"+reference+"%' or SERVICE LIKE '%"+reference+"%' or ETAT LIKE '%"+reference+"%')");

    if ( q.exec() )
    { modal->setQuery(q);
        ui->tableView->setModel(modal);}
    else
    {
        qWarning( "can't get value" ); }


}
/****************************************************************************/
bool equipements::en_marche(Ui::AfficherEquipements *ui)
{
    QSqlQuery q;

    QString id =ui->tableView->model()->data(ui->tableView->model()->index(ui->tableView->selectionModel()->currentIndex().row(),0)).toString();


    q.prepare("UPDATE EQUIPEMENTS set ETAT='en marche' WHERE REFERENCE ='"+id+"'") ;
    if ( q.exec())
    {
        q.prepare("SELECT COUNT(REFERENCE_EQUIPEMENT) FROM INTERVENTIONS where REFERENCE_EQUIPEMENT='"+id+"' ");
        q.exec();
        if ( q.first() )
        {
            int nb=q.value(0).toInt();

            if (nb!=0)
            { qWarning( "ok" );

                q.prepare("UPDATE INTERVENTIONS set ETAT='traitee'  WHERE REFERENCE_EQUIPEMENT ='"+id+"'");

                return    q.exec();}
            return true ;
        }}
    else
    {
        return false;
    }
}
/****************************************************************************/
bool equipements::en_panne(Ui::AfficherEquipements *ui)
{
    QSqlQuery q;

    QString id =ui->tableView->model()->data(ui->tableView->model()->index(ui->tableView->selectionModel()->currentIndex().row(),0)).toString();
    QString nom =ui->tableView->model()->data(ui->tableView->model()->index(ui->tableView->selectionModel()->currentIndex().row(),1)).toString();
    QString service =ui->tableView->model()->data(ui->tableView->model()->index(ui->tableView->selectionModel()->currentIndex().row(),2)).toString();

    static const char characters[] =
            "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890";

    int StringLength = sizeof(characters) - 1;
    QString code="";
    for (unsigned int i = 0; i <12; ++i)
    {
        code +=  characters[rand() % StringLength];
    }

    q.prepare("UPDATE EQUIPEMENTS set ETAT='en panne' WHERE REFERENCE ='"+id+"'") ;
    if ( q.exec())
    {
        q.prepare("SELECT COUNT(REFERENCE_EQUIPEMENT) FROM INTERVENTIONS where (REFERENCE_EQUIPEMENT='"+id+"' and ETAT='non traitee')");
        q.exec();
        if ( q.first() )
        {
            int nb=q.value(0).toInt();

            if (nb==0)
            {

                q.prepare("INSERT INTO INTERVENTIONS (REFERENCE_EQUIPEMENT,code, ETAT,NOM,SERVICE) "
                          "VALUES (:reference,:code,:etat,:nom,:service)");
                q.bindValue(":reference",id);
                q.bindValue(":nom", nom);
                q.bindValue(":service", service);
                q.bindValue(":code", code);
                q.bindValue(":etat", "non traitee");
                return    q.exec();
            }
            else {

                q.prepare("UPDATE INTERVENTIONS set ETAT='non traitee ' WHERE REFERENCE_EQUIPEMENT ='"+id+"'") ;
                return    q.exec();
            }
        }
        else
        {
            return false;
        }
    }
}

int equipements::nbre_En_Panne()
{  int nb;
    QSqlQuery q;

    q.prepare("SELECT COUNT(REFERENCE) FROM EQUIPEMENTS where ETAT='en panne'");
    q.exec();
    if ( q.first() )
        nb=q.value(0).toInt();

    return nb ;
}
/*****************************************************************************/
int equipements::nbre_En_Marche()
{  int nb;
    QSqlQuery q;

    q.prepare("SELECT COUNT(REFERENCE) FROM EQUIPEMENTS where ETAT='en marche' ");
    q.exec();
    if ( q.first() )
        nb=q.value(0).toInt();

    return nb ;
}

/******************************************************************************/
int equipements::nbre_total()
{  int nb,nb1;
    QSqlQuery q;

    q.prepare("SELECT COUNT(REFERENCE) FROM EQUIPEMENTS ");
    q.exec();
    if ( q.first() )
        nb=q.value(0).toInt();

    return nb;
}
