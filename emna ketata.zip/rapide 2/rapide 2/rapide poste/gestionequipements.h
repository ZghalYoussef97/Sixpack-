#ifndef GESTIONEQUIPEMENTS_H
#define GESTIONEQUIPEMENTS_H

#include <QMainWindow>

namespace Ui {
class GestionEquipements;
}

class GestionEquipements : public QMainWindow
{
    Q_OBJECT

public:
    explicit GestionEquipements(QWidget *parent = 0);
    ~GestionEquipements();

private slots:
    void on_Valider_clicked();

    void on_Annuler_clicked();

private:
    Ui::GestionEquipements *ui;
};

#endif // GESTIONEQUIPEMENTS_H
