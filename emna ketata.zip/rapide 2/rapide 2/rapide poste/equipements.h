#ifndef EQUIPEMENTS_H
#define EQUIPEMENTS_H
#include "afficherequipements.h"
#include "ui_afficherequipements.h"
#include "ui_interventions.h"
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include <QtCore/qglobal.h>
#include <QDate>
class equipements
{
public:
    equipements();


    equipements(QString reference,QString nom,QString service,QString mail,QDate date_ajout,QString descreption);
    QString get_reference();
    QString get_nom();
    QString get_service();
    QString get_mail();
    QString get_desc();
    QDate get_Date();
    int get_erreurs();
    bool modifier(Ui::AfficherEquipements *ui);

    void set_erreur();
    void set_reference(QString c);
    void afficher(Ui::AfficherEquipements *ui);
    void afficherIntervention(Ui::AfficherEquipements *ui);
    bool ajouter();
    bool Supprimer(Ui::AfficherEquipements *ui);
    void Tri_Ref(Ui::AfficherEquipements *ui) ;
    void Tri_NOM(Ui::AfficherEquipements *ui);

    void Recherche(Ui::AfficherEquipements *ui);
    int nbre_total();
    int nbre_En_Marche();
    int nbre_En_Panne();
    bool en_marche(Ui::AfficherEquipements *ui);
    bool en_panne(Ui::AfficherEquipements *ui);
private:
    QString nom,service,mail,etat,descreption;
    QString reference;
    QDate date_ajout;
    int erreurs=0;

    QString cn;
};

#endif // EQUIPEMENTS_H
