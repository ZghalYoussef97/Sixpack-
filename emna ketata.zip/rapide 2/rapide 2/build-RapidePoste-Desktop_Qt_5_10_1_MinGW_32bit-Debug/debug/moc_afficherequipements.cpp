/****************************************************************************
** Meta object code from reading C++ file 'afficherequipements.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.10.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../rapide poste/afficherequipements.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'afficherequipements.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.10.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_AfficherEquipements_t {
    QByteArrayData data[19];
    char stringdata0[376];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AfficherEquipements_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AfficherEquipements_t qt_meta_stringdata_AfficherEquipements = {
    {
QT_MOC_LITERAL(0, 0, 19), // "AfficherEquipements"
QT_MOC_LITERAL(1, 20, 22), // "on_tableView_activated"
QT_MOC_LITERAL(2, 43, 0), // ""
QT_MOC_LITERAL(3, 44, 5), // "index"
QT_MOC_LITERAL(4, 50, 16), // "on_panne_clicked"
QT_MOC_LITERAL(5, 67, 20), // "on_recherche_clicked"
QT_MOC_LITERAL(6, 88, 31), // "on_comboBox_currentIndexChanged"
QT_MOC_LITERAL(7, 120, 33), // "on_comboBox_2_currentIndexCha..."
QT_MOC_LITERAL(8, 154, 4), // "arg1"
QT_MOC_LITERAL(9, 159, 17), // "on_marche_clicked"
QT_MOC_LITERAL(10, 177, 19), // "on_modifier_clicked"
QT_MOC_LITERAL(11, 197, 21), // "on_modifier_2_clicked"
QT_MOC_LITERAL(12, 219, 25), // "on_Crecherche_textChanged"
QT_MOC_LITERAL(13, 245, 24), // "on_Crecherche_textEdited"
QT_MOC_LITERAL(14, 270, 20), // "on_tableView_clicked"
QT_MOC_LITERAL(15, 291, 18), // "on_annuler_clicked"
QT_MOC_LITERAL(16, 310, 20), // "on_supprimer_clicked"
QT_MOC_LITERAL(17, 331, 21), // "on_historique_clicked"
QT_MOC_LITERAL(18, 353, 22) // "on_equipements_clicked"

    },
    "AfficherEquipements\0on_tableView_activated\0"
    "\0index\0on_panne_clicked\0on_recherche_clicked\0"
    "on_comboBox_currentIndexChanged\0"
    "on_comboBox_2_currentIndexChanged\0"
    "arg1\0on_marche_clicked\0on_modifier_clicked\0"
    "on_modifier_2_clicked\0on_Crecherche_textChanged\0"
    "on_Crecherche_textEdited\0on_tableView_clicked\0"
    "on_annuler_clicked\0on_supprimer_clicked\0"
    "on_historique_clicked\0on_equipements_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AfficherEquipements[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   94,    2, 0x08 /* Private */,
       4,    0,   97,    2, 0x08 /* Private */,
       5,    0,   98,    2, 0x08 /* Private */,
       6,    1,   99,    2, 0x08 /* Private */,
       7,    1,  102,    2, 0x08 /* Private */,
       7,    1,  105,    2, 0x08 /* Private */,
       9,    0,  108,    2, 0x08 /* Private */,
      10,    0,  109,    2, 0x08 /* Private */,
      11,    0,  110,    2, 0x08 /* Private */,
      12,    1,  111,    2, 0x08 /* Private */,
      13,    1,  114,    2, 0x08 /* Private */,
      14,    1,  117,    2, 0x08 /* Private */,
      15,    0,  120,    2, 0x08 /* Private */,
      16,    0,  121,    2, 0x08 /* Private */,
      17,    0,  122,    2, 0x08 /* Private */,
      18,    0,  123,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QString,    8,
    QMetaType::Void, QMetaType::QModelIndex,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void AfficherEquipements::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        AfficherEquipements *_t = static_cast<AfficherEquipements *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_tableView_activated((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 1: _t->on_panne_clicked(); break;
        case 2: _t->on_recherche_clicked(); break;
        case 3: _t->on_comboBox_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_comboBox_2_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->on_comboBox_2_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_marche_clicked(); break;
        case 7: _t->on_modifier_clicked(); break;
        case 8: _t->on_modifier_2_clicked(); break;
        case 9: _t->on_Crecherche_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->on_Crecherche_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->on_tableView_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 12: _t->on_annuler_clicked(); break;
        case 13: _t->on_supprimer_clicked(); break;
        case 14: _t->on_historique_clicked(); break;
        case 15: _t->on_equipements_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject AfficherEquipements::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_AfficherEquipements.data,
      qt_meta_data_AfficherEquipements,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *AfficherEquipements::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AfficherEquipements::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_AfficherEquipements.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int AfficherEquipements::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 16;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
